call_suite for dyncall written in C and Lua.

