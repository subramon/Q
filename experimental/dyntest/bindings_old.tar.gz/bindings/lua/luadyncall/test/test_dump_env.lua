print("LUA_PATH      = ".. ( os.getenv("LUA_PATH") or "<undefined>" ) )
print("package.path  = "..package.path)
-- print("LUA_CPATH     = ".. ( os.getenv("LUA_CPATH") or "<undefined>" ) )
-- print("package.cpath = "..package.cpath)
