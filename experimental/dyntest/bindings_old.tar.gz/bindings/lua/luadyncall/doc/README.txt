LuaDoc will generate files here.. 

cd ../src and run makedoc.sh.

