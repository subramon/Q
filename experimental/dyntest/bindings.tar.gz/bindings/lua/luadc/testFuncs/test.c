#include <stdio.h>

double add(int a, float b) {
   return (double) a + b;
}
