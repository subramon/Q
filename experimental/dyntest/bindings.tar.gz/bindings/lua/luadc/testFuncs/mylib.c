#include <stdlib.h>
#include <math.h>
#include <inttypes.h>

#include "luaconf.h"
#include "lua.h"

#include "lauxlib.h"
#include "lualib.h"

static int add(lua_State *L){
  lua_Integer a = lua_tointeger(L, -1);
  lua_pop(L, 1);

  lua_Integer b = lua_tointeger(L, -1);
  lua_pop(L, 1);

  lua_Integer c = a+b;
  lua_pushinteger(L, c);
  return 1;
}

//library to be registered
static const struct luaL_Reg mylib [] = {
  {"adder", add},
  {NULL, NULL}  /* sentinel */
};

int luaopen_mylib (lua_State *L) {
  luaL_openlib(L, "mylib", mylib, 0);
  return 1;
}
