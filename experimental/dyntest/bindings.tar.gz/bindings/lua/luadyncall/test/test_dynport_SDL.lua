require"dynport"
dynport("SDL")
while true do print( SDL_GetTicks() ) end

