guess = require "ldynguess"

print("arch = "..guess.arch)
print("os = "..guess.os)
print("cc = "..guess.cc)

